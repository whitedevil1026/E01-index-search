// Copyright (C) 2022 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only


#ifndef SBK_QTQUICK_PYTHON_H
#define SBK_QTQUICK_PYTHON_H

#include <sbkpython.h>
#include <sbkmodule.h>
#include <sbkconverter.h>
// Module Includes
#include <pyside6_qtcore_python.h>
#include <pyside6_qtnetwork_python.h>
#include <pyside6_qtgui_python.h>
#include <pyside6_qtopengl_python.h>
#include <pyside6_qtqml_python.h>

// Bound library includes
#include <qquickframebufferobject.h>
#include <qquickitem.h>
#include <qquickopenglutils.h>
#include <qquickpainteditem.h>
#include <qquickrendertarget.h>
#include <qquickrhiitem.h>
#include <qquicktextdocument.h>
#include <qquickview.h>
#include <qquickwindow.h>
#include <qsggeometry.h>
#include <qsgimagenode.h>
#include <qsgmaterial.h>
#include <qsgmaterialshader.h>
#include <qsgnode.h>
#include <qsgrendererinterface.h>
#include <qsgrendernode.h>
#include <qsgsimpletexturenode.h>
#include <qsgtextnode.h>
#include <qsgtexture.h>
#include <qsharedpointer.h>

QT_BEGIN_NAMESPACE
class QQuickAsyncImageProvider;
class QQuickGraphicsConfiguration;
class QQuickGraphicsDevice;
class QQuickImageProvider;
class QQuickImageResponse;
class QQuickItemGrabResult;
class QQuickRenderControl;
class QQuickRhiItemRenderer;
class QQuickTextureFactory;
class QQuickTransform;
class QSGBasicGeometryNode;
class QSGClipNode;
class QSGDynamicTexture;
class QSGFlatColorMaterial;
class QSGGeometryNode;
struct QSGMaterialType;
class QSGNinePatchNode;
class QSGNodeVisitor;
class QSGOpacityNode;
class QSGOpaqueTextureMaterial;
class QSGRectangleNode;
class QSGRootNode;
class QSGSimpleRectNode;
class QSGTextureMaterial;
class QSGTextureProvider;
class QSGTransformNode;
class QSGVertexColorMaterial;
QT_END_NAMESPACE

// Type indices
enum : int {
    SBK_QQuickAsyncImageProvider_IDX                         = 16,
    SBK_QQuickFramebufferObject_IDX                          = 17,
    SBK_QQuickFramebufferObject_Renderer_IDX                 = 18,
    SBK_QQuickGraphicsConfiguration_IDX                      = 19,
    SBK_QQuickGraphicsDevice_IDX                             = 20,
    SBK_QQuickImageProvider_IDX                              = 21,
    SBK_QQuickImageResponse_IDX                              = 22,
    SBK_QQuickItem_Flag_IDX                                  = 24,
    SBK_QFlags_QQuickItem_Flag_IDX                           = 0,
    SBK_QQuickItem_ItemChange_IDX                            = 25,
    SBK_QQuickItem_MutabilityGroup_IDX                       = 26,
    SBK_QQuickItem_TransformOrigin_IDX                       = 27,
    SBK_QQuickItem_IDX                                       = 23,
    SBK_QQuickItem_UpdatePaintNodeData_IDX                   = 28,
    SBK_QQuickItemGrabResult_IDX                             = 29,
    SBK_QtQuickQQuickOpenGLUtils_IDX                         = 30,
    SBK_QQuickPaintedItem_RenderTarget_IDX                   = 33,
    SBK_QQuickPaintedItem_PerformanceHint_IDX                = 32,
    SBK_QFlags_QQuickPaintedItem_PerformanceHint_IDX         = 1,
    SBK_QQuickPaintedItem_IDX                                = 31,
    SBK_QQuickRenderControl_IDX                              = 34,
    SBK_QQuickRenderTarget_Flag_IDX                          = 36,
    SBK_QFlags_QQuickRenderTarget_Flag_IDX                   = 2,
    SBK_QQuickRenderTarget_IDX                               = 35,
    SBK_QQuickRhiItem_TextureFormat_IDX                      = 38,
    SBK_QQuickRhiItem_IDX                                    = 37,
    SBK_QQuickRhiItemRenderer_IDX                            = 39,
    SBK_QQuickTextDocument_Status_IDX                        = 41,
    SBK_QQuickTextDocument_IDX                               = 40,
    SBK_QQuickTextureFactory_IDX                             = 42,
    SBK_QQuickTransform_IDX                                  = 43,
    SBK_QQuickView_ResizeMode_IDX                            = 45,
    SBK_QQuickView_Status_IDX                                = 46,
    SBK_QQuickView_IDX                                       = 44,
    SBK_QQuickWindow_CreateTextureOption_IDX                 = 48,
    SBK_QFlags_QQuickWindow_CreateTextureOption_IDX          = 3,
    SBK_QQuickWindow_RenderStage_IDX                         = 50,
    SBK_QQuickWindow_SceneGraphError_IDX                     = 51,
    SBK_QQuickWindow_TextRenderType_IDX                      = 52,
    SBK_QQuickWindow_IDX                                     = 47,
    SBK_QQuickWindow_GraphicsStateInfo_IDX                   = 49,
    SBK_QSGBasicGeometryNode_IDX                             = 53,
    SBK_QSGClipNode_IDX                                      = 54,
    SBK_QSGDynamicTexture_IDX                                = 55,
    SBK_QSGFlatColorMaterial_IDX                             = 56,
    SBK_QSGGeometry_AttributeType_IDX                        = 60,
    SBK_QSGGeometry_DataPattern_IDX                          = 62,
    SBK_QSGGeometry_DrawingMode_IDX                          = 63,
    SBK_QSGGeometry_Type_IDX                                 = 66,
    SBK_QSGGeometry_IDX                                      = 57,
    SBK_QSGGeometry_Attribute_IDX                            = 58,
    SBK_QSGGeometry_AttributeSet_IDX                         = 59,
    SBK_QSGGeometry_ColoredPoint2D_IDX                       = 61,
    SBK_QSGGeometry_Point2D_IDX                              = 64,
    SBK_QSGGeometry_TexturedPoint2D_IDX                      = 65,
    SBK_QSGGeometryNode_IDX                                  = 67,
    SBK_QSGImageNode_TextureCoordinatesTransformFlag_IDX     = 69,
    SBK_QFlags_QSGImageNode_TextureCoordinatesTransformFlag_IDX = 4,
    SBK_QSGImageNode_IDX                                     = 68,
    SBK_QSGMaterial_Flag_IDX                                 = 71,
    SBK_QFlags_QSGMaterial_Flag_IDX                          = 5,
    SBK_QSGMaterial_IDX                                      = 70,
    SBK_QSGMaterialShader_Flag_IDX                           = 73,
    SBK_QFlags_QSGMaterialShader_Flag_IDX                    = 6,
    SBK_QSGMaterialShader_Stage_IDX                          = 82,
    SBK_QSGMaterialShader_IDX                                = 72,
    SBK_QSGMaterialShader_GraphicsPipelineState_BlendFactor_IDX = 75,
    SBK_QSGMaterialShader_GraphicsPipelineState_BlendOp_IDX  = 76,
    SBK_QSGMaterialShader_GraphicsPipelineState_ColorMaskComponent_IDX = 77,
    SBK_QFlags_QSGMaterialShader_GraphicsPipelineState_ColorMaskComponent_IDX = 7,
    SBK_QSGMaterialShader_GraphicsPipelineState_CullMode_IDX = 78,
    SBK_QSGMaterialShader_GraphicsPipelineState_PolygonMode_IDX = 79,
    SBK_QSGMaterialShader_GraphicsPipelineState_IDX          = 74,
    SBK_QSGMaterialShader_RenderState_DirtyState_IDX         = 81,
    SBK_QFlags_QSGMaterialShader_RenderState_DirtyState_IDX  = 8,
    SBK_QSGMaterialShader_RenderState_IDX                    = 80,
    SBK_QSGMaterialType_IDX                                  = 83,
    SBK_QSGNinePatchNode_IDX                                 = 84,
    SBK_QSGNode_NodeType_IDX                                 = 88,
    SBK_QSGNode_Flag_IDX                                     = 87,
    SBK_QFlags_QSGNode_Flag_IDX                              = 10,
    SBK_QSGNode_DirtyStateBit_IDX                            = 86,
    SBK_QFlags_QSGNode_DirtyStateBit_IDX                     = 9,
    SBK_QSGNode_IDX                                          = 85,
    SBK_QSGNodeVisitor_IDX                                   = 89,
    SBK_QSGOpacityNode_IDX                                   = 90,
    SBK_QSGOpaqueTextureMaterial_IDX                         = 91,
    SBK_QSGRectangleNode_IDX                                 = 92,
    SBK_QSGRenderNode_StateFlag_IDX                          = 96,
    SBK_QFlags_QSGRenderNode_StateFlag_IDX                   = 12,
    SBK_QSGRenderNode_RenderingFlag_IDX                      = 95,
    SBK_QFlags_QSGRenderNode_RenderingFlag_IDX               = 11,
    SBK_QSGRenderNode_IDX                                    = 93,
    SBK_QSGRenderNode_RenderState_IDX                        = 94,
    SBK_QSGRendererInterface_GraphicsApi_IDX                 = 98,
    SBK_QSGRendererInterface_Resource_IDX                    = 100,
    SBK_QSGRendererInterface_ShaderType_IDX                  = 103,
    SBK_QSGRendererInterface_ShaderCompilationType_IDX       = 101,
    SBK_QFlags_QSGRendererInterface_ShaderCompilationType_IDX = 13,
    SBK_QSGRendererInterface_ShaderSourceType_IDX            = 102,
    SBK_QFlags_QSGRendererInterface_ShaderSourceType_IDX     = 14,
    SBK_QSGRendererInterface_RenderMode_IDX                  = 99,
    SBK_QSGRendererInterface_IDX                             = 97,
    SBK_QSGRootNode_IDX                                      = 104,
    SBK_QSGSimpleRectNode_IDX                                = 105,
    SBK_QSGSimpleTextureNode_TextureCoordinatesTransformFlag_IDX = 107,
    SBK_QFlags_QSGSimpleTextureNode_TextureCoordinatesTransformFlag_IDX = 15,
    SBK_QSGSimpleTextureNode_IDX                             = 106,
    SBK_QSGTextNode_TextStyle_IDX                            = 110,
    SBK_QSGTextNode_RenderType_IDX                           = 109,
    SBK_QSGTextNode_IDX                                      = 108,
    SBK_QSGTexture_WrapMode_IDX                              = 114,
    SBK_QSGTexture_Filtering_IDX                             = 113,
    SBK_QSGTexture_AnisotropyLevel_IDX                       = 112,
    SBK_QSGTexture_IDX                                       = 111,
    SBK_QSGTextureMaterial_IDX                               = 115,
    SBK_QSGTextureProvider_IDX                               = 116,
    SBK_QSGTransformNode_IDX                                 = 117,
    SBK_QSGVertexColorMaterial_IDX                           = 118,
    SBK_QSharedPointer_QQuickItemGrabResult_IDX              = 120, // QSharedPointer<QQuickItemGrabResult>
    SBK_QSharedPointer_constQQuickItemGrabResult_IDX         = 120, // (const)
    SBK_QtQuick_IDX_COUNT                                    = 121,
};

// This variable stores all Python types exported by this module.
extern Shiboken::Module::TypeInitStruct *SbkPySide6_QtQuickTypeStructs;

// This variable stores the Python module object exported by this module.
extern PyObject *SbkPySide6_QtQuickModuleObject;

// This variable stores all type converters exported by this module.
extern SbkConverter **SbkPySide6_QtQuickTypeConverters;

// Converter indices
enum [[deprecated]] : int {
    SBK_QTQUICK_QLIST_INT_IDX                                = 0, // QList<int>
    SBK_QTQUICK_QLIST_QSGGEOMETRY_POINT2D_IDX                = 1, // QList<QSGGeometry::Point2D>
    SBK_QTQUICK_QLIST_QBYTEARRAY_IDX                         = 2, // QList<QByteArray>
    SBK_QTQUICK_QLIST_QQUICKITEMPTR_IDX                      = 3, // QList<QQuickItem*>
    SBK_QTQUICK_QLIST_QQMLERROR_IDX                          = 4, // QList<QQmlError>
    SBK_QTQUICK_QMAP_QSTRING_QVARIANT_IDX                    = 5, // QMap<QString,QVariant>
    SBK_QTQUICK_QLIST_QVARIANT_IDX                           = 6, // QList<QVariant>
    SBK_QTQUICK_QLIST_QSTRING_IDX                            = 7, // QList<QString>
    SBK_QTQUICK_CONVERTERS_IDX_COUNT                         = 8,
};

// Converter indices
enum : int {
    SBK_QtQuick_QList_int_IDX                                = 0, // QList<int>
    SBK_QtQuick_QList_QSGGeometry_Point2D_IDX                = 1, // QList<QSGGeometry::Point2D>
    SBK_QtQuick_QList_QByteArray_IDX                         = 2, // QList<QByteArray>
    SBK_QtQuick_QList_QQuickItemPTR_IDX                      = 3, // QList<QQuickItem*>
    SBK_QtQuick_QList_QQmlError_IDX                          = 4, // QList<QQmlError>
    SBK_QtQuick_QMap_QString_QVariant_IDX                    = 5, // QMap<QString,QVariant>
    SBK_QtQuick_QList_QVariant_IDX                           = 6, // QList<QVariant>
    SBK_QtQuick_QList_QString_IDX                            = 7, // QList<QString>
    SBK_QtQuick_CONVERTERS_IDX_COUNT                         = 8,
};
// Macros for type check

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace Shiboken
{

// PyType functions, to get the PyObjectType for a type T
template<> inline PyTypeObject *SbkType< ::QQuickAsyncImageProvider >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickAsyncImageProvider_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickFramebufferObject >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickFramebufferObject_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickFramebufferObject::Renderer >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickFramebufferObject_Renderer_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickGraphicsConfiguration >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickGraphicsConfiguration_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickGraphicsDevice >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickGraphicsDevice_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickImageProvider >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickImageProvider_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickImageResponse >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickImageResponse_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickItem::Flag >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickItem_Flag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QQuickItem::Flag> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QQuickItem_Flag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickItem::ItemChange >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickItem_ItemChange_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickItem::MutabilityGroup >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickItem_MutabilityGroup_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickItem::TransformOrigin >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickItem_TransformOrigin_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickItem >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickItem_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickItem::UpdatePaintNodeData >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickItem_UpdatePaintNodeData_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickItemGrabResult >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickItemGrabResult_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickPaintedItem::RenderTarget >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickPaintedItem_RenderTarget_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickPaintedItem::PerformanceHint >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickPaintedItem_PerformanceHint_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QQuickPaintedItem::PerformanceHint> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QQuickPaintedItem_PerformanceHint_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickPaintedItem >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickPaintedItem_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickRenderControl >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickRenderControl_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickRenderTarget::Flag >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickRenderTarget_Flag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QQuickRenderTarget::Flag> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QQuickRenderTarget_Flag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickRenderTarget >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickRenderTarget_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickRhiItem::TextureFormat >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickRhiItem_TextureFormat_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickRhiItem >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickRhiItem_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickRhiItemRenderer >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickRhiItemRenderer_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickTextDocument::Status >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickTextDocument_Status_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickTextDocument >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickTextDocument_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickTextureFactory >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickTextureFactory_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickTransform >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickTransform_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickView::ResizeMode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickView_ResizeMode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickView::Status >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickView_Status_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickView >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickView_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickWindow::CreateTextureOption >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickWindow_CreateTextureOption_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QQuickWindow::CreateTextureOption> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QQuickWindow_CreateTextureOption_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickWindow::RenderStage >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickWindow_RenderStage_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickWindow::SceneGraphError >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickWindow_SceneGraphError_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickWindow::TextRenderType >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickWindow_TextRenderType_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickWindow >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickWindow_IDX]); }
template<> inline PyTypeObject *SbkType< ::QQuickWindow::GraphicsStateInfo >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QQuickWindow_GraphicsStateInfo_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGBasicGeometryNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGBasicGeometryNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGClipNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGClipNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGDynamicTexture >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGDynamicTexture_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGFlatColorMaterial >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGFlatColorMaterial_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGGeometry::AttributeType >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGGeometry_AttributeType_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGGeometry::DataPattern >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGGeometry_DataPattern_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGGeometry::DrawingMode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGGeometry_DrawingMode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGGeometry::Type >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGGeometry_Type_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGGeometry >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGGeometry_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGGeometry::Attribute >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGGeometry_Attribute_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGGeometry::AttributeSet >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGGeometry_AttributeSet_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGGeometry::ColoredPoint2D >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGGeometry_ColoredPoint2D_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGGeometry::Point2D >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGGeometry_Point2D_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGGeometry::TexturedPoint2D >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGGeometry_TexturedPoint2D_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGGeometryNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGGeometryNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGImageNode::TextureCoordinatesTransformFlag >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGImageNode_TextureCoordinatesTransformFlag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QSGImageNode::TextureCoordinatesTransformFlag> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QSGImageNode_TextureCoordinatesTransformFlag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGImageNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGImageNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterial::Flag >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterial_Flag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QSGMaterial::Flag> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QSGMaterial_Flag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterial >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterial_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterialShader::Flag >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterialShader_Flag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QSGMaterialShader::Flag> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QSGMaterialShader_Flag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterialShader::Stage >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterialShader_Stage_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterialShader >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterialShader_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterialShader::GraphicsPipelineState::BlendFactor >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterialShader_GraphicsPipelineState_BlendFactor_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterialShader::GraphicsPipelineState::BlendOp >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterialShader_GraphicsPipelineState_BlendOp_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterialShader::GraphicsPipelineState::ColorMaskComponent >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterialShader_GraphicsPipelineState_ColorMaskComponent_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QSGMaterialShader::GraphicsPipelineState::ColorMaskComponent> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QSGMaterialShader_GraphicsPipelineState_ColorMaskComponent_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterialShader::GraphicsPipelineState::CullMode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterialShader_GraphicsPipelineState_CullMode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterialShader::GraphicsPipelineState::PolygonMode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterialShader_GraphicsPipelineState_PolygonMode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterialShader::GraphicsPipelineState >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterialShader_GraphicsPipelineState_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterialShader::RenderState::DirtyState >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterialShader_RenderState_DirtyState_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QSGMaterialShader::RenderState::DirtyState> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QSGMaterialShader_RenderState_DirtyState_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterialShader::RenderState >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterialShader_RenderState_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGMaterialType >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGMaterialType_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGNinePatchNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGNinePatchNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGNode::NodeType >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGNode_NodeType_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGNode::Flag >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGNode_Flag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QSGNode::Flag> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QSGNode_Flag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGNode::DirtyStateBit >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGNode_DirtyStateBit_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QSGNode::DirtyStateBit> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QSGNode_DirtyStateBit_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGNodeVisitor >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGNodeVisitor_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGOpacityNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGOpacityNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGOpaqueTextureMaterial >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGOpaqueTextureMaterial_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGRectangleNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGRectangleNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGRenderNode::StateFlag >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGRenderNode_StateFlag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QSGRenderNode::StateFlag> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QSGRenderNode_StateFlag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGRenderNode::RenderingFlag >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGRenderNode_RenderingFlag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QSGRenderNode::RenderingFlag> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QSGRenderNode_RenderingFlag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGRenderNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGRenderNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGRenderNode::RenderState >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGRenderNode_RenderState_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGRendererInterface::GraphicsApi >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGRendererInterface_GraphicsApi_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGRendererInterface::Resource >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGRendererInterface_Resource_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGRendererInterface::ShaderType >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGRendererInterface_ShaderType_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGRendererInterface::ShaderCompilationType >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGRendererInterface_ShaderCompilationType_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QSGRendererInterface::ShaderCompilationType> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QSGRendererInterface_ShaderCompilationType_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGRendererInterface::ShaderSourceType >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGRendererInterface_ShaderSourceType_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QSGRendererInterface::ShaderSourceType> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QSGRendererInterface_ShaderSourceType_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGRendererInterface::RenderMode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGRendererInterface_RenderMode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGRendererInterface >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGRendererInterface_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGRootNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGRootNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGSimpleRectNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGSimpleRectNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGSimpleTextureNode::TextureCoordinatesTransformFlag >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGSimpleTextureNode_TextureCoordinatesTransformFlag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QFlags<QSGSimpleTextureNode::TextureCoordinatesTransformFlag> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QFlags_QSGSimpleTextureNode_TextureCoordinatesTransformFlag_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGSimpleTextureNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGSimpleTextureNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGTextNode::TextStyle >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGTextNode_TextStyle_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGTextNode::RenderType >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGTextNode_RenderType_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGTextNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGTextNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGTexture::WrapMode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGTexture_WrapMode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGTexture::Filtering >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGTexture_Filtering_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGTexture::AnisotropyLevel >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGTexture_AnisotropyLevel_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGTexture >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGTexture_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGTextureMaterial >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGTextureMaterial_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGTextureProvider >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGTextureProvider_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGTransformNode >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGTransformNode_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSGVertexColorMaterial >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSGVertexColorMaterial_IDX]); }
template<> inline PyTypeObject *SbkType< ::QSharedPointer<QQuickItemGrabResult> >() { return Shiboken::Module::get(SbkPySide6_QtQuickTypeStructs[SBK_QSharedPointer_QQuickItemGrabResult_IDX]); }

} // namespace Shiboken

QT_WARNING_POP
#endif // SBK_QTQUICK_PYTHON_H

